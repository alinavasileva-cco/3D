@echo off
cd /d "%~dp0"
"C:\Program Files\Blender Foundation\Blender 5.3\5.3\python\bin\python.exe" "%~dp0TABLE_01_VIEWER_LOCAL.py"
if errorlevel 1 pause
