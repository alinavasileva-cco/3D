# Local-only offline viewer server for EUREKA 3D. No public access.
from pathlib import Path
import http.server, functools, socketserver, threading, webbrowser
ROOT=Path(__file__).resolve().parent
class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
Handler=functools.partial(Handler,directory=str(ROOT))
with socketserver.TCPServer(("127.0.0.1",0),Handler) as server:
    port=server.server_address[1]
    url=f"http://127.0.0.1:{port}/TABLE_01_EUREKA_360.html"
    print("Открыть модель: "+url,flush=True)
    print("Для завершения закройте это окно или нажмите Ctrl+C",flush=True)
    webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
